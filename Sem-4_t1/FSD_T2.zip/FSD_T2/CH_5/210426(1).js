/* Write Express js script to print msg in splitling by "." use get method to get data2.html file contains from of text area for the message and submit button.
 */

const express = require("express");
const app = express();

app.use(express.static(__dirname, { index: "2.html" }));

app.get("/login", (req, res) => {
  res.set("content-type", "text/html");
  t1 = req.query.MSG.split(".");

  for (i in t1) {
    res.write(t1[i] + "<br>");
  }
  res.send();
});
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
