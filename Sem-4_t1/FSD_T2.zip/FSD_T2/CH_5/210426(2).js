const express = require("express");
const app = express();

// Serve your HTML file
app.use(express.static(__dirname, { index: "210426(2).html" }));

app.get("/calc", (req, res) => {
  res.set("content-type", "text/html");

  let n1 = parseInt(req.query.n1);
  let n2 = parseInt(req.query.n2);
  let formula = req.query.formula;
  let result;

  if (n1 > 0 && n2 > 0) {
    
   if (formula == "additon") {
     result = n1 + n2;
     res.send("Addition is: " + result);
   } else if (formula == "subtraction") {
     result = n1 - n2;
     res.send("Subtraction is: " + result);
   } else if (formula == "Multiplication") {
     result = n1 * n2;
     res.send("Multiplication is: " + result);
   } else if (formula == "Divison") {
     result = n1 / n2;
     res.send("Division is: " + result);
   } else {
     res.write("You Have Not Selected Any Formula");
   }
  } 
  else {
    res.write("Please Enter Valid Number");
  }
});

// Listen on port 3000
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
