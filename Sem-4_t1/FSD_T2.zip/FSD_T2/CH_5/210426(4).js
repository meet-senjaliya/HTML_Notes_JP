// create a html form that take number 
// on submission if i/p is empty, displaye "please Enter a number"
// or if i/p is not a number display "Invalid input".
// If number is : display Even num is it is even or show odd if it is odd

// use HTTp post method

const express = require("express");
const app = express();

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Serve static HTML file
app.use(express.static(__dirname, { index: "210426(4).html" }));

app.post("/check", (req,res)=>{
    const num = req.body.num;

    if(!num){
        res.send("pleaase enter number <a href='/' >Try Again</a>");
    }
    if(isNaN(num)){
        res.send("Invalid Input <a href='/'>Try Again</a>")
    }
    const number = Number(num)

    if(number%2 == 0){
        res.send("Even Number <a href='/'> Try again</a>")
    }
    else{
        res.send("Odd Number <a href='/'> Try again</a>")
    }
})
app.listen(5055)