const express = require("express")
const app = express();

const path = require("path")
const staticpath = path.join(12wz
    __dirname,"../Frontend"
);

app.use(express.static(staticpath));
app.listen(6001);