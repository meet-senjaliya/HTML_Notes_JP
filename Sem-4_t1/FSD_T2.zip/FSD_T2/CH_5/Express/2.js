const express = require("express")
const app = express();

app.use(express.static("Frontend"));

app.listen(6001);

