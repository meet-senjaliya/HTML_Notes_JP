const express = require("express")
const app = express();

app.use(express.static(__dirname));
/* Here, express.static(__dirname) is middleware that serves static files (HTML, CSS, JS, images) from the given directory.

So if you have index.html in the same folder, visiting http://localhost:6001/ will automatically serve that file.*/
app.listen(6001);

// 1.js it will automaticaly connect with the index.html