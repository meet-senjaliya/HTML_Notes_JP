/* create a login form using  a html  with feilds: username, password, submit button

on form submission : if username=admin and password = 1234 then displayed login success
otherwise dispaly "Invalid Credentials" and provide link to go back.
use post metod and submit data to "/login"
*/


const express = require("express");
const app = express();

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Serve static HTML file
app.use(express.static(__dirname, { index: "210426(3).html" }));

// Handle POST request
app.post("/login", (req, res) => {
  const { uname, pwd } = req.body;

  res.set("content-type", "text/html");

  if (uname == "admin" && pwd == "1234") {
    res.send("<h2>Login Success</h2>");
  } else {
    res.send(`
      <h2>Invalid Credentials</h2>
      <a href="/">Go Back</a>
    `);
  }
});

// Start server
app.listen(3001, () => {
  console.log("Server running at http://localhost:3001");
});
