const express = require("express");
const app = express();

app.use(
  express.urlencoded({
    extended: true,
  }),
);

app.get("/", (req, res) => {
  res.send(`
        <form action="/login" method="post">
            Name:<input type="text" name="uname" />
            Email:<input type="email" name="email" />
            <input type="checkbox" name="news" />Subscribe?
            <input type="submit" value="submit" />
        </form>
  `);
});

app.post("/login", (req, res) => {
  res.set("Content-Type", "text/html");

  let response = `<h1>Welcome: ${req.body.uname}</h1>`;
  response += `<p>Your Email: ${req.body.email}</p>`;

  if (req.body.news === "on") {
    response += `<h3>Thank You for subscribing</h3> <a href="/">logout</a>`;
  } else {
    response += `<h3>You may subscribe</h3> <a href="/subscribe">subscribe</a>`;
  }

  res.send(response);
});

app.get("/subscribe", (req, res) => {
  res.set("Content-Type", "text/html");
  res.send("Thank you <a href='/'> logout</a>");
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
