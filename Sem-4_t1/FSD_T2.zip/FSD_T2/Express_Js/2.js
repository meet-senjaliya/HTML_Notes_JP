var express = require("express");
var app = express();

app.get('/', function(req,res){
    res.set("content-type","text/plain");
    res.write("HII 81")// header set
    res.send("Hello") //2 nd time set header
    res.setHeader
})
app.listen(5001);
