var express = require("express");
var app = express();

app.get('/', function(req,res){
    res.set("content-type","text/plain");
    res.send("Hello") //set the header by self
    res.setHeader
})
app.listen(5001);
