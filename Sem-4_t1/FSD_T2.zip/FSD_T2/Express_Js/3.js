// var express = require("express");
// var app = express();

// app.get('/', function(req,res){
//   res.set("content-type", "text/plain");
//   //res.write("HII"); // header set
//   res.write("<i>Hello</i>"); // header set
//   res.send(); //2 nd time set header

// })
// app.listen(5001);

var express = require("express");
var app = express();

app.get("/", function (req, res) {
  //res.set("content-type", "text/plain");
  //res.write("HII"); // header set
  //res.write("<i>Hello</i>"); // header set
  res.send("<i>Hello</i>"); // header set
});
app.listen(6007);
