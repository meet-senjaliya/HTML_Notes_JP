var express = require("express");
var app = express();

app.get("/", function (req, res) {
  res.set("content-type", "text/plain");
  res.send("<i>Hello</i>")
});
app.listen(6002);
